select sum(j.ff) nyc_ff_jan18 from fares_jan18 j;
